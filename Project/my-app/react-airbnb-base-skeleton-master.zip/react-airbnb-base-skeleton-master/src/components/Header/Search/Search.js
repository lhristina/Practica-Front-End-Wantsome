import React from "react";

const Search = () => <input value="Search" />;

export default Search;
